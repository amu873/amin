/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void PrintPair(int a[], int n){
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            cout<<"("<<a[i]<<","<<a[j]<<")";
        }
        cout<<endl;
    }
}

int main()
{
    int a[4]={1,2,3,4};
    int n;
    n=sizeof(a)/sizeof(int);
    PrintPair(a,n);

    return 0;
}