/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
//subarraySum using kadane's algorithm
using namespace std;
int subarraySum(int a[],int n){
    int largestSum=0,currentSum=0;
    for(int i=0;i<n;i++){
        currentSum+=a[i];
        if(currentSum<0){
            currentSum=0;
        }
        else 
         {
             largestSum=max(largestSum,currentSum);
         }
    }
    
    return largestSum;
}
int main()
{ 
    int a[5]={2,-3,10,-4,-5};
    int n;
    n=sizeof(a)/sizeof(int);
   cout<<"largest subarray sum is : "<<subarraySum(a,n);
    

    return 0;
}