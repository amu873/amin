/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
//largest subarray sum
int LargestSubarraySum(int arr[], int n){
    int largestSum=0;
    for(int i=0;i<n;i++){
        for(int j=i;j<n;j++){
            int subarraySum=0;
            
            for(int k=i;k<=j;k++)
            {
               subarraySum+=arr[k];
                
            }
          
            largestSum=max(largestSum,subarraySum);
        }
        
    }
    return largestSum;
}
int main()
{
     int arr[4]={1,-2,3,4};
    int n;
    n=sizeof(arr)/sizeof(int);
    cout<<"largest subaray sum is : "<<LargestSubarraySum(arr,n);

    return 0;
}
