/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void print( /*int arr[] or*/int *arr, int n){
    //int n; agr apna int n = sizeof arr/sze of int keya toh
    //8 byte ans ayga:Reason hai k idr pointer aya ha or pointer ka size ha 8
    
    cout<<"\n in printf array is "<<endl;
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
}

int main()
{
    int arr[]={1,2,3,4,5,6};
    int n;
    n= sizeof(arr)/sizeof(int);

    cout<<"in main array is :"<<endl;
      for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    
        print(arr,n);
    //idr hum address send kry hain hain exmple arr[0] ka addres=100
    //yhi address hoga puri array ka b but isko snd krygy toh address snd hoga mtlb srf ek pointer ka size
    

    return 0;
}