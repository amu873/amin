/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

***********************************************************/
#include <iostream>
//sub array sum using pefix
using namespace std;
void subarraySumPrefix(int a[], int n){
    int prefixArray[n]={0};
    int subarraySum=0,largestSum=0;
    int i=0,j=0;
    prefixArray[0]=a[0];
    
    for(int i=1;i<n;i++){
        prefixArray[i]=  prefixArray[i-1]+a[i]; 
    }
    
    for(int i=1;i<<n;i++){
        for(int j=i;j<n;j++)
        
    {
        subarraySum=prefixArray[j]-prefixArray[i-1];
        largestSum=max(largestSum,subarraySum);
    }
    }
    cout<<largestSum;
    
}
int main()
{
    int a[6]={1,-2,3,4,-5,6};
    int n;
    n=sizeof(a)/sizeof(int);
    cout<<"sub array sum using prefix : ";
    subarraySumPrefix(a,n);

    return 0;
}